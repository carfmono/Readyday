Paquete de arranque para Power BI - Garmin / Salud / Rendimiento / Longevidad

Archivos:
- garmin_powerbi_dashboard_template.xlsx
- guia_powerbi_garmin.docx
- powerbi_theme_garmin.json
- powerbi_measures_garmin.txt
- powerbi_layout_exacto.md
- daily_log_template_powerbi.csv

Importante:
- No fue posible generar un .pbix nativo en este entorno porque Power BI Desktop es quien serializa ese formato.
- Con estos archivos puedes montar el reporte rápidamente:
  1. Abre Power BI Desktop
  2. Importa daily_log_template_powerbi.csv o la hoja Daily_Log del Excel
  3. Aplica el tema JSON
  4. Crea las medidas DAX desde el archivo TXT
  5. Distribuye los visuales según powerbi_layout_exacto.md